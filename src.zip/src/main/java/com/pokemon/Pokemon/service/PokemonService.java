package com.pokemon.Pokemon.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class PokemonService {

    private final WebClient webClient;
    private final MongoTemplate mongoTemplate;

    @Autowired
    public PokemonService(WebClient.Builder webClientBuilder, MongoTemplate mongoTemplate) {
        this.webClient = webClientBuilder.baseUrl("https://pokeapi.co/api/v2/pokemon/ditto").build();
        this.mongoTemplate = mongoTemplate;
    }


    public void fetchDataFromApiAndStoreInMongoDB() {
        System.out.println("Service");
        // Make an API request and retrieve data as JSON
        String jsonData = webClient.get()
                .uri("https://pokeapi.co/api/v2/pokemon/ditto")

                .retrieve()
                .bodyToMono(String.class)
                .block();
        System.out.println(jsonData);

        // Convert JSON to a MongoDB document (BSON)
        org.bson.Document document = new org.bson.Document();
        document.put("jsonData", jsonData);

        // Store the document in MongoDB
        mongoTemplate.insert(document, "Pokemon");
    }
}
