package com.pokemon.Pokemon.Controller;

import com.pokemon.Pokemon.service.PokemonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v2/pokemon")
public class PokemonController {

    @Autowired
    private PokemonService pokemonService;

    @GetMapping("/ditto")
    public String fetchAndStoreData() {
        pokemonService.fetchDataFromApiAndStoreInMongoDB();
        System.out.println("controller working");
        return "Data fetched from the API and stored in MongoDB!";
    }
}
