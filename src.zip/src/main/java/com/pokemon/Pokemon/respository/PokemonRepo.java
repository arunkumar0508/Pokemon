package com.pokemon.Pokemon.respository;

import com.mongodb.client.MongoCollection;
import org.bson.Document;
import org.springframework.stereotype.Repository;


public interface PokemonRepo{
    void save(String jsonData, String collectionName);
}
