package com.pokemon.Pokemon.respository;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class PokemonRepoImpl implements PokemonRepo{

    private final MongoTemplate mongoTemplate;

    @Autowired
    public PokemonRepoImpl(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @Override
    public void save(String jsonData, String collectionName) {
        Document document = Document.parse(jsonData);
        mongoTemplate.insert(document, collectionName);
    }
}
